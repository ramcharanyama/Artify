# Artify Backend

This is the separate backend folder for the Artify project.

## Setup

1. Open a terminal in this `backend` folder.
2. Install dependencies:
   npm install
3. Start backend server:
   npm start

The backend runs on:

- http://localhost:5000

## Available API Endpoints

- GET /api/health
- GET /api/bootstrap
- GET /api/users
- POST /api/auth/login
- POST /api/auth/register
- GET /api/gallery
- POST /api/gallery
- GET /api/orders
- POST /api/orders
- PATCH /api/orders/:id
- GET /api/forum
- POST /api/forum
- POST /api/forum/:id/vote

## Data Storage

All app data is stored in:

- backend/data/db.json

This includes users, gallery, orders, and forum posts.

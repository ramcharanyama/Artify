const express = require('express');
const cors = require('cors');
const fs = require('fs/promises');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;
const DB_PATH = path.join(__dirname, 'data', 'db.json');

app.use(cors());
app.use(express.json());

async function readDb() {
  const raw = await fs.readFile(DB_PATH, 'utf8');
  return JSON.parse(raw);
}

async function writeDb(data) {
  await fs.writeFile(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
}

function mapGalleryWithArtist(db) {
  return db.gallery.map((item) => {
    const artistUser = db.users.find((u) => u.id === item.artistId);
    return {
      ...item,
      artist: artistUser ? artistUser.name : 'Unknown Artist',
    };
  });
}

function mapArtists(db, galleryData) {
  const users = db.users.filter((u) => u.role === 'artist');
  return users.map((u) => ({
    id: u.id,
    name: u.name,
    style: galleryData.find((g) => g.artistId === u.id)?.style || 'Mixed Media',
    img: `https://ui-avatars.com/api/?name=${encodeURIComponent(u.name)}&background=random&color=fff`,
    desc: 'Professional artist delivering museum-quality results. Passionate about capturing raw emotion and translating concepts into breathtaking visual realities.',
    rating: 4.8,
    revCount: 50,
    yearsExperience: 5,
    totalArtworks: galleryData.filter((g) => g.artistId === u.id).length + 20,
    reviews: [
      { user: 'Sarah J.', rating: 5, comment: 'Absolutely stunning work! Captured the essence perfectly.', date: '2 days ago' },
    ],
  }));
}

app.get('/api/health', (_req, res) => {
  res.json({
    success: true,
    message: 'Artify backend is running',
    timestamp: new Date().toISOString(),
  });
});

app.get('/api/bootstrap', async (_req, res) => {
  try {
    const db = await readDb();
    const gallery = mapGalleryWithArtist(db);
    const artists = mapArtists(db, gallery);
    const users = db.users.map(({ pass, ...safeUser }) => safeUser);

    res.json({ users, gallery, artists, orders: db.orders, forum: db.forum });
  } catch (error) {
    res.status(500).json({ message: 'Failed to load bootstrap data.' });
  }
});

app.get('/api/users', async (_req, res) => {
  try {
    const db = await readDb();
    const users = db.users.map(({ pass, ...safeUser }) => safeUser);
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: 'Failed to load users.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, pass } = req.body;
    if (!email || !pass) return res.status(400).json({ message: 'Email and password are required.' });

    const db = await readDb();
    const user = db.users.find((u) => u.email === email && u.pass === pass);
    if (!user) return res.status(401).json({ message: 'Invalid credentials.' });

    const { pass: _p, ...safeUser } = user;
    res.json({ user: safeUser });
  } catch (error) {
    res.status(500).json({ message: 'Failed to login.' });
  }
});

app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, pass, role } = req.body;
    if (!name || !email || !pass) return res.status(400).json({ message: 'Name, email and password are required.' });

    const db = await readDb();
    if (db.users.some((u) => u.email === email)) return res.status(409).json({ message: 'Email already in use.' });

    const newUser = {
      id: `usr-${Date.now()}`,
      name,
      email,
      pass,
      role: role === 'artist' ? 'artist' : 'customer',
    };
    db.users.push(newUser);
    await writeDb(db);

    const { pass: _p, ...safeUser } = newUser;
    res.status(201).json({ user: safeUser });
  } catch (error) {
    res.status(500).json({ message: 'Failed to register.' });
  }
});

app.get('/api/gallery', async (_req, res) => {
  try {
    const db = await readDb();
    res.json(mapGalleryWithArtist(db));
  } catch (error) {
    res.status(500).json({ message: 'Failed to load gallery.' });
  }
});

app.post('/api/gallery', async (req, res) => {
  try {
    const { title, artistId, style, price, img, desc, rating } = req.body;
    if (!title || !artistId || !style || !price || !img) {
      return res.status(400).json({ message: 'title, artistId, style, price, and img are required.' });
    }

    const db = await readDb();
    const newArtwork = {
      id: Date.now(),
      title,
      artistId,
      style,
      price: Number(price),
      img,
      desc: desc || '',
      rating: Number(rating) || 5,
    };
    db.gallery.push(newArtwork);
    await writeDb(db);

    const artistUser = db.users.find((u) => u.id === newArtwork.artistId);
    res.status(201).json({ ...newArtwork, artist: artistUser ? artistUser.name : 'Unknown Artist' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to add artwork.' });
  }
});

app.get('/api/orders', async (_req, res) => {
  try {
    const db = await readDb();
    res.json(db.orders);
  } catch (error) {
    res.status(500).json({ message: 'Failed to load orders.' });
  }
});

app.post('/api/orders', async (req, res) => {
  try {
    const db = await readDb();
    const newOrder = req.body;
    db.orders.unshift(newOrder);
    await writeDb(db);
    res.status(201).json(newOrder);
  } catch (error) {
    res.status(500).json({ message: 'Failed to create order.' });
  }
});

app.patch('/api/orders/:id', async (req, res) => {
  try {
    const db = await readDb();
    const order = db.orders.find((o) => o.id === req.params.id);
    if (!order) return res.status(404).json({ message: 'Order not found.' });

    Object.assign(order, req.body || {});
    await writeDb(db);
    res.json(order);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update order.' });
  }
});

app.get('/api/forum', async (_req, res) => {
  try {
    const db = await readDb();
    res.json(db.forum);
  } catch (error) {
    res.status(500).json({ message: 'Failed to load forum.' });
  }
});

app.post('/api/forum', async (req, res) => {
  try {
    const { title, user, content, img, type } = req.body;
    if (!title || !user || !content) return res.status(400).json({ message: 'title, user, and content are required.' });

    const db = await readDb();
    const newPost = {
      id: Date.now(),
      title,
      user,
      time: 'Just now',
      content,
      img: img || '',
      upvotes: 1,
      comments: 0,
      type: type || 'new',
    };
    db.forum.unshift(newPost);
    await writeDb(db);
    res.status(201).json(newPost);
  } catch (error) {
    res.status(500).json({ message: 'Failed to publish post.' });
  }
});

app.post('/api/forum/:id/vote', async (req, res) => {
  try {
    const { vote } = req.body;
    if (vote !== 'up' && vote !== 'down') return res.status(400).json({ message: 'vote must be up or down.' });

    const db = await readDb();
    const post = db.forum.find((p) => String(p.id) === String(req.params.id));
    if (!post) return res.status(404).json({ message: 'Post not found.' });

    post.upvotes += vote === 'up' ? 1 : -1;
    await writeDb(db);
    res.json(post);
  } catch (error) {
    res.status(500).json({ message: 'Failed to vote on post.' });
  }
});

app.listen(PORT, () => {
  console.log(`Artify backend listening on http://localhost:${PORT}`);
});
